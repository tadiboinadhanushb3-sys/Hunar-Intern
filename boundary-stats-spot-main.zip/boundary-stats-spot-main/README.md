# IPL Analytics Dashboard (2008–2019)

Interactive analytics dashboard built with **React + TypeScript + Vite + Tailwind CSS + Recharts + shadcn/ui**.

## Features
- **Overview** — totals (matches, runs, wickets, sixes, fours), highest team score, season trends, toss impact
- **Players** — top run scorers, top wicket takers, strike rate leaders, Orange & Purple cap
- **Teams** — win % rankings, head-to-head comparison
- **Matches** — scorecard, runs per over
- **Venues** — most-hosted grounds, average score, batting-first win %
- **CSV upload** — drop in `matches.csv` and `deliveries.csv` (Kaggle IPL schema)
- **Dynamic filters** — season, team, venue, player
- **CSV export** — download filtered subsets
- **Responsive** dark sports UI

## CSV Schema
Compatible with the Kaggle IPL dataset.

**matches.csv**: `id, season, city, date, team1, team2, toss_winner, toss_decision, result, winner, win_by_runs, win_by_wickets, player_of_match, venue`

**deliveries.csv**: `match_id, inning, batting_team, bowling_team, over, ball, batsman, bowler, wide_runs, bye_runs, legbye_runs, noball_runs, penalty_runs, batsman_runs, extra_runs, total_runs, player_dismissed, dismissal_kind`

If no CSV is uploaded, a generated sample dataset for 2008–2019 is used.

## Develop
```bash
bun install
bun dev
```

## Deploy
The frontend is fully static after `bun run build` — deployable to **GitHub Pages**, **Vercel**, or **Netlify**. Default output: `dist/`.
